import React, { useState, useEffect } from 'react';

const segments = ['MCX', 'NSE', 'Forex', 'Crypto'];

const generateRandomData = (segment) => {
  // Generate sample stock data
  const symbols = {
    MCX: ['GOLD', 'SILVER', 'CRUDEOIL', 'COPPER'],
    NSE: ['RELIANCE', 'TCS', 'INFY', 'HDFC'],
    Forex: ['USDINR', 'EURINR', 'GBPUSD', 'JPYINR'],
    Crypto: ['BTC', 'ETH', 'XRP', 'LTC']
  };

  return symbols[segment].map(symbol => {
    const ltp = (Math.random() * 100 + 1000).toFixed(2);
    const change = (Math.random() * 5 - 2.5).toFixed(2);
    const changePercent = ((change / ltp) * 100).toFixed(2);
    const high = (parseFloat(ltp) + Math.random() * 10).toFixed(2);
    const low = (parseFloat(ltp) - Math.random() * 10).toFixed(2);
    const volume = Math.floor(Math.random() * 10000);
    return {
      symbol,
      ltp,
      change,
      changePercent,
      high,
      low,
      volume
    };
  });
};

function MarketWatchTable({ data }) {
  return (
    <table className="market-table">
      <thead>
        <tr>
          <th>Symbol</th>
          <th>LTP</th>
          <th>Change</th>
          <th>Change %</th>
          <th>High</th>
          <th>Low</th>
          <th>Volume</th>
        </tr>
      </thead>
      <tbody>
        {data.map(item => (
          <tr key={item.symbol}>
            <td>{item.symbol}</td>
            <td>{item.ltp}</td>
            <td style={{color: item.change >= 0 ? '#4ade80' : '#f87171'}}>
              {item.change >= 0 ? '+' : ''}{item.change}
            </td>
            <td style={{color: item.changePercent >= 0 ? '#4ade80' : '#f87171'}}>
              {item.changePercent >= 0 ? '+' : ''}{item.changePercent}%
            </td>
            <td>{item.high}</td>
            <td>{item.low}</td>
            <td>{item.volume}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function App() {
  const [segment, setSegment] = useState('MCX');
  const [data, setData] = useState([]);

  useEffect(() => {
    // Load initial data
    setData(generateRandomData(segment));
  }, [segment]);

  useEffect(() => {
    // Set interval to update data every 1 second
    const interval = setInterval(() => {
      setData(generateRandomData(segment));
    }, 1000);
    return () => clearInterval(interval);
  }, [segment]);

  return (
    <div className="app-container">
      <header>
        <h1>Express Trading - Market Watch</h1>
      </header>
      <nav className="segment-tabs">
        {segments.map(seg => (
          <button
            key={seg}
            className={seg === segment ? 'active' : ''}
            onClick={() => setSegment(seg)}
          >
            {seg}
          </button>
        ))}
      </nav>
      <MarketWatchTable data={data} />
      <footer>
        <small>Demo data, auto-refresh every 1 second</small>
      </footer>
    </div>
  );
}

export default App;
