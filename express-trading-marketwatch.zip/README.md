# Express Trading Market Watch

This is a React demo app simulating a Market Watch page inspired by tradepluss.live.

Features:
- Tabs for MCX, NSE, Forex, Crypto segments
- Auto-refresh every 1 second with simulated data
- Dark theme with blue-gold styling
- Responsive design

Run locally:
1. npm install
2. npm start
